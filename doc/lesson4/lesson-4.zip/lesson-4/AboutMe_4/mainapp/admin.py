from django.contrib import admin
from mainapp.models import Hobby

#admin.site.register(Hobby)

from django.apps import AppConfig


class UsermanageConfig(AppConfig):
    name = 'usermanage'

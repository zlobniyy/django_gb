from django.contrib import admin
from .models import Categorymodel, Imagemodel
# Register your models here.
